<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 
    <title>WEattitude  <?php if(!empty($title)){
        echo "|" .$title;
    }?></title>

    <!-- Styles -->

    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(url('/public/selectize/selectize.bootstrap3.css')); ?>">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/custom.css')); ?>">
  
    <link rel="stylesheet" id="theme" type="text/css" href="<?php echo e(url('public/css/homepage.css')); ?>"/>

   
    <!--slider css-->
    <link rel="stylesheet" id="theme" type="text/css" href="<?php echo e(url('public/slider/css/default.css')); ?>"/>
    <link rel="stylesheet" id="theme" type="text/css" href="<?php echo e(url('public/slider/css/component.css')); ?>"/>
    <script type="text/javascript" src="<?php echo e(url('public/slider/js/modernizr.custom.js')); ?>"></script>
<!--slider css end-->
<!--selectize assets-->
    <script src="<?php echo e(url('/public/selectize/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('/public/selectize/selectize.js')); ?>"></script>
<!--selectize assets end--> 
<style type="text/css">
    .footer{position: fixed;bottom: 0;left: 0;right: 0;}
    img {width: 30%;}
</style>
  
  
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        WEattitude.org
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    YOURattitude <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                                    <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>

                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('home')); ?>">YOURattitude</a></li>
                        <?php endif; ?>
                            
                            <li><a href="<?php echo e(route('aboutUs')); ?>">About Us</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    Motivation Resources
                                     <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        
                                        <a href="<?php echo e(route('hangoutSheet')); ?>"><i class="fas fa-folder-open"></i> Handout Sheet for Your Community</a>
                                    </li>                                     
                                    <li>  
                                        <a href="<?php echo e(route('writingVideos')); ?>"><i class="fas fa-video"></i> Daily Collections of Uplifting Writings & Videos</a>
                                    </li>                                     
                                    <li>

                                        <a href="<?php echo e(route('whyParticipate')); ?>"><i class="fas fa-undo-alt"></i> What do Participants Get in Return </a>
                                    </li> 
                                </ul>  
                            </li>              
                            <li class='dropdown'>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Ongoing Initiatives <span class="caret"></span></a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('issueSuggestedSolution')); ?>"><i class="fas fa-check-circle"></i>
                                            Issues & Suggested Solutions
                                        </a>
                                    </li>

                                    <li>
                                        <?php if(Auth::guest()): ?>
                                        <a href="<?php echo e(url('login')); ?>"><i class="fas fa-undo-alt"></i> Here is What You Can do</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('myProfile')); ?>"><i class="fas fa-undo-alt"></i> Here is What You Can do</a>
                                        <?php endif; ?>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(route('caseStudy')); ?>"><i class="fas fa-search"></i> Case Studies / Success Stories</a>
                                    </li>
                                </ul>
                            </li>
                                                
                        <?php if(Auth::guest()): ?>
                       
                        <?php else: ?>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('setting')); ?>">Setting</a>
                                    </li> <!--                         
                                    <li>
                                    <a href="<?php echo e(route('changePassword')); ?>">Change Password</a>
                                    </li>                         -->           
                                    <li>
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
<div class="clearfix"></div>
        <div class="container-fluid footer">
            <strong><center>&copy; All Rights Reserved | WEattitude.org</center> </strong>
        </div>
    </div>

    <!-- Scripts -->
  
    <script src="<?php echo e(url('public/js/2.1.4-jquery.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/app.js')); ?>"></script>
    
    <!--bootstrap tags js-->
    
    <script src="https://unpkg.com/ionicons@4.0.0/dist/ionicons.js"></script> 
<!--slider js -->
        <script src="<?php echo e(url('public/slider/js/jquery.imagesloaded.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/slider/js/cbpBGSlideshow.min.js')); ?>"></script>
        <script>
            $(function() {
                cbpBGSlideshow.init();
            });
        </script>    
<!--slider js end-->    
    <!--js area-->
    <?php echo $__env->yieldContent('js'); ?>
    <!--js area end-->  
</body>

</html>
