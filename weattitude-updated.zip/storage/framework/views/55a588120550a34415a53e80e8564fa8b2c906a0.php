<?php $__env->startSection('content'); ?>
<div class="container otherpage-area">
<?php 
function limit_text($text, $limit) {
      if (str_word_count($text, 0) > $limit) {
          $words = str_word_count($text, 2);
          $pos = array_keys($words);
          $text = substr($text, 0, $pos[$limit]) . '...';
      }
      return $text;
    }
?>	
	<div class="col-md-10 col-md-offset-2">
		<?php $__empty_1 = true; $__currentLoopData = $videoContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
		<div class="author">
			<img class='img-thumbnail' src="<?php echo e(url('storage/app/avatars/')); ?>/<?php echo e($value->image); ?>">
			<span>By : <a><?php echo e($value->name); ?></a></span>
			<span>On : <a><?php echo $date= date('d F, Y',strtotime($value->created_at))?></a> </span>
		</div>
		<div class="blog">
			<h1 class="blog-title"><a href="<?= url('/uplifting-writing-videos-detail/'.$value->id)?>"><?php echo e($value->title); ?></a></h1>
			<div class="tags">
				<?php 
					$tags= $value->tags;
					$array= explode(',', $tags);
					$n= count($array);
					if($n>0):
					for($i=0; $i<$n; $i++):
						$tag= $array[$i]
				?>
				<a href="<?php echo url('uplifting-writing-videos/tag/'.$tag)?>"><?= $array[$i]?></a>
				<?php 
					endfor;
					endif;
				?>
			</div>

			<div class="essay">
				<p>
					<?php 
					echo limit_text($value->essay, 25);
					?>
				</p>
				<div class="continue">
					<a href="<?= url('/uplifting-writing-videos-detail/'.$value->id)?>" class="btn primary continue-btn">Continue reading...</a>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
		<h3>No record found</h3>
		<?php endif; ?>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>