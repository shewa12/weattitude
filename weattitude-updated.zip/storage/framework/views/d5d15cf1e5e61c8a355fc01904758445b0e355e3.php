<html>
<head>
	<title>WeAttitude.org | Handout Sheet</title>
</head>
<body>
	<h1 align="center">WEattitude.org</h1>
	<div style='border:2px solid #e3e3e3; padding:10px;'>
		<h3>Handout Sheet for Your Community</h3>
		<?php echo $data;?>
	</div>
</body>
</html>