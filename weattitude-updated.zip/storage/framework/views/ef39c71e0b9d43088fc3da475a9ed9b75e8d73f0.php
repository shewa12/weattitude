<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row" style="margin-top:50px;">
<!--carousel slider--> 
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
     

          <!-- Wrapper for slides -->
          <div class="carousel-inner">
        <?php $i= 1;?>    
        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
        <?php if($i++==1): ?>
            <div class="item active">
                <div class="panel-default panel">
                    <div class="panel-heading"><?php echo e($project->location_name); ?></div>
                    <div class="panel-body">
                         <?php $project_id=  $project->id?>
                        <div class="project_indicators col-md-6"> 
                        <?php $__empty_2 = true; $__currentLoopData = $indicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_2 = false; ?>
                        <?php if($project_id==$value->project_id): ?>
                            <div class="alert alert-info">
                                <i class="<?php echo e($value->icon); ?>"></i>
                                <span class="indicator-title">
                                    <?php echo e($value->title); ?>

                                </span>
                                <span class="direction">
                                    <i class="<?php echo e($value->direction); ?>"></i>
                                </span>
                                <span class="value">
                                    <?php echo e($value->indicator_value); ?>

                                </span>
                            </div>                        
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_2): ?>
                        <?php endif; ?> 
                        </div>      
                        <div class="detail">
                            <h3>Success Detail</h3>
                            <?php echo e($project->detail); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="item">
                <div class="panel-default panel">
                    <div class="panel-heading"><?php echo e($project->location_name); ?></div>
                    <div class="panel-body">
                        <?php $project_id = $project->id?>
                        <div class="project_indicators col-md-6"> 
                        <?php $__empty_2 = true; $__currentLoopData = $indicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_2 = false; ?>
                        <?php if($project_id==$value->project_id): ?>
                            <div class="alert alert-info">
                                <i class="<?php echo e($value->icon); ?>"></i>
                                <span class="indicator-title">
                                    <?php echo e($value->title); ?>

                                </span>
                                <span class="direction">
                                    <i class="<?php echo e($value->direction); ?>"></i>
                                </span>
                                <span class="value">
                                    <?php echo e($value->indicator_value); ?>

                                </span>
                            </div>                        
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_2): ?>
                        <?php endif; ?> 
                        </div> 
                        <div class="detail">
                            <h3>Success Detail</h3>
                            <?php echo e($project->detail); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
        <h3>No record found</h3>
        <?php endif; ?>    

          </div>
          <!-- Indicators -->
          <?php $slide=0;?>
          <ol class="carousel-indicators" style="margin-top: 100px;background: #0003;width: 100px;text-align: center;border-radius: 10px;">

            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <?php if($slide++==0): ?>
            <li data-target="#myCarousel" data-slide-to="<?php echo e($slide-1); ?>" class="active"></li>
            <?php else: ?>
            <li data-target="#myCarousel" data-slide-to="<?php echo e($slide-1); ?>"></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>

          <?php endif; ?>            
          </ol>     

        </div>       
<!--carousel slider end-->        
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>