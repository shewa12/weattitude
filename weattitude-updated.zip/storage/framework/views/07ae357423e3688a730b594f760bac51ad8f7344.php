<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<?php if(Session::has('success')): ?>
		<div class="alert-success alert">
			<h4><?php echo Session::get('success'); ?></h4>
			
		</div>
		<?php endif; ?>
		<?php if(Session::has('fail')): ?>
		<div class="alert-danger alert">
			<h4><?php echo Session::get('fail'); ?></h4>
		</div>
		<?php endif; ?>	
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            	<div class="panel-heading">Update Password</div>
				<div class="panel-body">
					<form class="form-horizontal form col-md-4 col-md-offset-4 col-lg-4 col-lg-offset" method="post" action="<?php echo e(route('updatePassword')); ?>">
						<?php echo e(csrf_field()); ?>


						<div class="form-group">
							<label>Old Password</label>
							<input type="password" class="form-control" name="old_password">
							    <?php if($errors->has('old_password')): ?>
			                        <span class="help-block">
			                            <strong><?php echo e($errors->first('oldpass')); ?></strong>
			                        </span>
			                    <?php endif; ?>
						</div>			

						<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
							<label>New Password</label>
							<input type="password" class="form-control" name="password"></input>
							    <?php if($errors->has('password')): ?>
			                        <span class="help-block">
			                            <strong><?php echo e($errors->first('password')); ?></strong>
			                        </span>
			                    <?php endif; ?>
						</div>			

						<div class="form-group">
							<label>Confirm Password</label>
							<input type="password" class="form-control" name="password_confirmation"></input>
							    <?php if($errors->has('password_confirmation')): ?>
			                        <span class="help-block">
			                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
			                        </span>
			                    <?php endif; ?>		
						</div>			

						<div class="form-group">
							<button class="btn-default btn">Update Password</button>
						</div>
					</form>
				</div>

            </div>
        </div>    		
		


	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>