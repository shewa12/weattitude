
<!--sidebar menu for teacher start-->
       <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                
                <ul class="nav side-menu">
                  <li><a href="<?php echo e(url('')); ?>"><i class="fas fa-home"></i> Website</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('workLog')); ?>"><i class="fas fa-briefcase"></i> Work Log</a>
                  </li>                  
                  <li>
                    <a href="<?php echo e(route('workLog')); ?>"><i class="fas fa-clipboard-list"></i> Schedule</a>
                  </li>                  

                  <li>
                    <a href="<?php echo e(route('workLog')); ?>"><i class="fas fa-book-open"></i> Note Book</a>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Top Courses <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    
                      <li><a href=""> Courses</a></li>
                   
                      <li><a href="">Sub Courses</a></li>

                    </ul>
                  </li>                  

                  <li>
                    <a><i class="fa fa-edit"></i>Course Collections <span class="fa fa-chevron-down"></span></a>
                    
                    <ul class="nav child_menu">
                    
                      <li><a href=""> Courses</a></li>
                   
                      <li><a href=""> Sub Courses</a></li>

                    </ul>
                  </li>
                  <li><a><i class="fa fa-desktop"></i>Lessons<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li>
                        <a href="">Top Course Lessons</a>
                      </li>                     
                       <li>
                        <a href=""> Course Collection Lessons</a>
                      </li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-desktop"></i>Quiz<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li>
                        <a href="">Top Sub Course Quiz</a>
                      </li>                     
                       <li>
                        <a href="">Collection Sub Course Quiz</a>
                      </li>
                    </ul>
                  </li>
                                  
                  <li>
                    <a><i class="fa fa-desktop"></i>Student's Query<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li>
                        <a href="">Top Course Query</a>
                      </li>                     
                       <li>
                        <a href="">Collection Course Query</a>
                      </li>
                    </ul>                    
                  </li>
                
              </ul>
             
              </div>


            </div>
<!--sidebar menu for teacher end-->
