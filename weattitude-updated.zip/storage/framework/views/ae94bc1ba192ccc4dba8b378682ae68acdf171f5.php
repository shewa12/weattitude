<?php $__env->startSection('content'); ?>
  <div class="right_col" role="main">
      <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  

        <div class="responsive">
            <button class="btn-default btn btn-sm" data-toggle="modal" data-target="#addform"><i class="fas fa-plus-circle"></i> Video / Essay</button>
            <table class="table table-bordered table-hover" id="table">
                <thead>
                <tr>
                    <th>Sl No:</th>
                    
                    <th>Video</th>
                    <th>Essay</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $i=1;
                  ?>

                <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td>
                      <div class="embed-responsive embed-responsive-4by3" style="width:240px">
                        <iframe class="embed-responsive-item" src="<?php echo e(url('storage/app/videos/').'/'.$value->video); ?>"></iframe>
                      </div>                      

                      
                    </td>
                    <td><?php echo e($value->essay); ?></td>

                     
                        <?php 
                        /*
                        echo 
                        '
                        <i class="fas fa-edit" onClick ="edit('.$value->id.',\''.$value->name.'\')" data-toggle="modal" data-target="#editform"
                        aria-hidden="true" style="color:green; font-size:18px;cursor:pointer;"></i>

                        ';
                        */
                        ?>
                        <td>
                        <?php 
                        echo 
                        '
                        <i class="fas fa-trash-alt" onClick ="deleteUser('.$value->id.')" data-toggle="modal" 
                        aria-hidden="true" style="color:red; font-size:18px;cursor:pointer;"></i>

                        ';
                        ?>
                        </td>
                        
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                  <tr>
                    <td>No record found</td>
                  </tr>
                <?php endif; ?>
                </tbody>
            </table>    
        </div>      

<!-- Modal for add -->
<div class="modal fade" id="addform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Video / Essay</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('saveVideo')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

         

          <div class="form-group">
            <label>Video</label>
            <input class="form-control" type="file" name="video"></input>
          </div>          

          <div class="form-group">
            <label>Essay</label>
            <textarea class="form-control" name="essay" placeholder="add initiatives"></textarea>
          </div>

          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--modal for add end-->   

<!--edit form--> 

<div class="modal fade" id="editform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Service</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('updateIssue')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

          <input type="hidden" name="id">
          <div class="form-group">
            <label for="name">Name</label>
            <input class="form-control" name="name" id="name" required></input>
          </div>          

          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--edit form end--> 
  </div><!--main  col div end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script type="text/javascript">
//this script for check is it img or not
$(document).ready(function(){
  $('[name="video"]').change(function(){
    var img = $(this).val();
  if (!img.match(/(?:mp4|avi|mov)$/)) {
    // inputted file path is not an image of one of the above types
    alert("please select an image!");
     $('[name="video"]').val('');
  }
  });
//SIZE VALIDATION
         $('[name="video"]').bind('change', function() {
            var size= this.files[0].size/1024/1024;
            if(size>25){
              alert("Please upload file less than 25mb");
              $('[name="video"]').val('');
            }
        });
//SIZE VALIDATION

});
//deleting 
 
  </script>
  <script type="text/javascript">

      function deleteUser(id){
        
       var url ="<?php echo url('delete-video')?>";

        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
            $.ajax({

              url : url+'/'+id,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                  
               $("#table").load(location.href+" #table");
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error deleting data');
              }
          });

        }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>