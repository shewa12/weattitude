<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row" style="margin-top:50px;">
			<h1 class="page-title">Advance Search Result</h1>
            <div class='table-responsive'>
                <table class='table table-border'>
                    <thead>
                        <tr>
                            <th>Sl No.</th>
                            <th>Issues</th>
                            <th>Severities</th>
                            <th>Initiatives</th>
                            <th>Recommendations</th>
                            
                        </tr>
                    </thead>

                    <tbody>
                    <?php $i= 1;?>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>	
		                <tr>
		                    <td><?php echo e($i++); ?></td>
		                    <td><?php echo e($value->content); ?></td>
		                    <td><?php echo e($value->severity); ?></td>
		                    <td><?php echo e($value->initiatives); ?></td>
		                    <td><?php echo e($value->recommendation); ?></td>
		                </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
		            <tr>
		            	<td>No record found</td>
		            </tr>    
		            <?php endif; ?>
                    </tbody>
                </table>
                <a class="btn-default btn" href="<?php echo e(route('issueSuggestedSolution')); ?>">Back</a>
            </div>            
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>