
<!--sidebar menu for teacher start-->
       <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
                
            <ul class="nav side-menu">
                  <li><a href="<?php echo e(route('users')); ?>"><i class="fas fa-user-alt"></i> Technician</a>
                  </li>
                  <li><a href="<?php echo e(route('appUsers')); ?>"><i class="fas fa-users"></i> Users</a>
                  </li>
                  <li>
                    <a href="<?php echo e(route('getServices')); ?>"><i class="fas fa-briefcase"></i> Services</a>
                  </li>                  
                  <li>
                    <a href="<?php echo e(route('getFeatures')); ?>"><i class="fas fa-clipboard-list"></i> Features</a>
                  </li>                  

                  <li>
                    <a href="<?php echo e(route('getLocations')); ?>"><i class="fas fa-map-marker-alt"></i> Locations</a>
                  </li>
                

    
              </ul>
             
              </div>


            </div>
<!--sidebar menu for teacher end-->
