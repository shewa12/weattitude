<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>My Profile</title>
    <!-- Styles -->
    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous"> 
    <script src="<?php echo e(url('public/js/2.1.4-jquery.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/app.js')); ?>"></script>       
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
      	height:450px;
      } 
    </style>
  </head>

<body>
  <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        WEattitude.org
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                        
                            <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                       
                        <?php else: ?>
                        <li>
                            <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('myProfile')); ?>">My Profile</a>

                        </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('setting')); ?>">Setting</a>
                                    </li> <!--                         
                                    <li>
                                    <a href="<?php echo e(route('changePassword')); ?>">Change Password</a>
                                    </li>                         -->           
                                    <li>
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
  </div>
  <div class="container">
    <div class="row">
        <div class="col-md-3 info">
            <div class="panel-default panel">
                <div class="panel-body">
                  <center>
                    <img class="img-responsive img-thumbnail" src="<?php echo e(url('storage/app/avatars').'/'.$user->image); ?>" style="width:120px;height:120px;border-radius:60px;"/>
                    <h3><?php echo e($user->name); ?></h3>
                    </center>
                </div>
            </div>            

            <div class="panel-default panel">
                <div class="panel-heading">
                    <h3 align="center"> Your Interest/ Hobbies / Skills</h3>
                </div>
                <div class="panel-body interest">
                    <?php $__empty_1 = true; $__currentLoopData = $interest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                        <?php if($value->type=="Job Role"): ?>
                      <p><strong><i class="fas fa-briefcase job-icon"></i> <?php echo e($value->interest); ?></strong></p>
                        <?php elseif($value->type=="Skill"): ?>
                      <p><strong><i class="fas fa-check-circle skill-icon"></i> <?php echo e($value->interest); ?></strong></p>
                        <?php elseif($value->type=="Hobby"): ?>
                      <p><strong><i class="fas fa-smile hobby-icon"></i> <?php echo e($value->interest); ?></strong></p>
                        <?php else: ?>
                      <p><strong><i class="fas fa-th custom-icon"></i> <?php echo e($value->interest); ?></strong></p>

                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <strong>No record found</strong>
                    <?php endif; ?>  
                </div>
            </div>
        </div>

        <!--gmap-->
        <div class="col-md-9">
            <div id="map"></div>
        </div>
        <!--gmap end-->
    </div>
  </div>

    <script>
      var content;
      var customLabel = {
        restaurant: {
          label: 'R'
        },
        bar: {
          label: 'B'
        }
      };

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(23.684994, 90.356331),
          zoom: 7
        });
        // latlngbounds = new google.maps.LatLngBounds();
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file

          downloadUrl("<?php echo url('/markers')?>", function(data) {

            var xml = data.responseXML;
            
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var title = markerElem.getAttribute('location_name');
              var address = markerElem.getAttribute('location_level');
              var type = markerElem.getAttribute('parent_level');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));
              
              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = title
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label,
                animation: google.maps.Animation.DROP
              });
//bounds start

             // latlngbounds.extend(point);
              //map.fitBounds(latlngbounds); 

//bounds end              
              marker.addListener('click', function() {

                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);

              });

            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDgB7vF_nyTAIBpEyHUjtE0bzNXoTNrqcc&callback=initMap">
    </script>
  </body>
</html>