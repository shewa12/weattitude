<?php $__env->startSection('content'); ?>
<div class="test">
	<h3>hello</h3>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
$(document).ready(function() {  
	setInterval(function(){
		$("body").animate({
			backgroundColor:"#000"
		},200);
	},2000);
 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>