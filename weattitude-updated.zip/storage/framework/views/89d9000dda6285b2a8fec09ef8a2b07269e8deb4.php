<?php $__env->startSection('content'); ?>
<div class="container otherpage-area">

	<div class="col-md-8 col-md-offset-2">
		<?php $__empty_1 = true; $__currentLoopData = $videoContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>

		<h1 align="center" class="blog-title"><a href=""><?php echo e($value->title); ?></a></h1>

		<div class="author" style="text-align:center;margin-bottom:40px">
			<img class='img-thumbnail' src="<?php echo e(url('storage/app/avatars/')); ?>/<?php echo e($value->image); ?>">
			<span>By : <a><?php echo e($value->name); ?></a></span>
			<span>On : <a><?php echo $date= date('d F, Y',strtotime($value->created_at))?></a> </span>
		</div>
		<div class="video" style="margin-bottom:40px;">
			<div class="embed-responsive embed-responsive-16by9">
			  <iframe class="embed-responsive-item" src="<?php echo e(url('storage/app/videos/')); ?>/<?php echo e($value->video); ?>" allowfullscreen></iframe>
			</div>	
		</div>			
		<div class="blog">
			

			<div class="essay">
				<p>
					<?php echo e($value->essay); ?>

				</p>

			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
		<h3>No record found</h3>
		<?php endif; ?>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>