<?php $__env->startSection('content'); ?>
	<div class="right_col" role="main">
		  <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  

        <div class="responsive">
            <button class="btn-default btn btn-sm" data-toggle="modal" data-target="#addform"><i class="fas fa-plus-circle"></i>User</button>
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>Sl No:</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone Number</th>
                    <th>Age</th>
                    <th>Region</th>
                    <th>Zipcode</th>
                    <th>Recognition Sign</th>
                    <th>About</th>
                    <th>Send Mail</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                	<?php 
                		$i=1;
                	?>

                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                	<tr>
                		<td><?php echo e($i++); ?></td>
                    <td><img src="<?php echo e(url('storage/app/avatars/')); ?>/<?php echo e($value->image); ?>" style="width:60px;height:60px;border-radius:30px;"></td>                    
                		<td><?php echo e($value->name); ?></td>
                		<td><?php echo e($value->email); ?></td>
                		<td><?php echo e($value->address); ?></td>
                		<td><?php echo e($value->phoneNumber); ?></td>
                		<td><?php echo e($value->age); ?></td>
                		<td><?php echo e($value->region); ?></td>
                		<td><?php echo e($value->zipCode); ?></td>
                    <td><?php echo e($value->recognitionSign); ?></td>
                    <td><?php echo e($value->about); ?></td>
                		<td>
                        <button onclick="sendMail(<?php echo $value->id?>)" type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">Send</button>
                    </td>
                        <td> 
                        <?php 
                        
                        echo 
                        '
                        <i class="fas fa-edit" onClick ="edit('.$value->id.',\''.$value->name.'\', \''.$value->email.'\',\''.$value->address.'\', \''.$value->phoneNumber.'\',\''.$value->age.'\',\''.$value->region.'\',\''.$value->zipCode.'\',\''.$value->recognitionSign.'\',\''.$value->password.'\')" data-toggle="modal" data-target="#editform"
                        aria-hidden="true" style="color:green; font-size:18px;cursor:pointer;"></i>

                        ';
                        ?>
                        </td>
                        <td class="" id="dlt"><i id="delete" onClick="deleteUser(<?php echo e($value->id); ?>)" class=" fas fa-trash-alt" style="color:red; font-size:18px;cursor:pointer;"></i></td>                		
                	</tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                	<tr>
                		<td>No record found</td>
                	</tr>
                <?php endif; ?>
                </tbody>
            </table>    
        </div>      

<!-- Modal for add -->
<div class="modal fade" id="addform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add work log</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('saveUser')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="image">Add Image</label>
            <input type="file" class="form-control" name="image" id="image" required></input>
          </div>
          <div class="form-group">
            <label for="name">User Name</label>
            <input class="form-control" name="name" id="name" required></input>
          </div>          

          <div class="form-group">
            <label for="age">Age</label>
            <input class="form-control" name="age" id="age"></input>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" name="email" id="email" required></input>
          </div>             

          <div class="form-group">
            <label for="password">Password</label>
            <input class="form-control" name="password" id="password" required></input>
          </div>           
          <div class="form-group">
            <label for="Address">Address</label>
            <input class="form-control" name="address" id="Address"></input>
          </div>           
          <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input class="form-control" name="phoneNumber" id="phoneNumber"></input>
          </div>           

           <div class="form-group">
            <label for="region">Region Number</label>
            <input class="form-control" name="region" id="region"></input>
          </div>           

           <div class="form-group">
            <label for="zipCode">Zip Code</label>
            <input class="form-control" name="zipCode" id="zipCode"></input>
          </div>              

          <div class="form-group">
            <label for="recognitionSign">Recognition Sign</label>
            <input class="form-control" name="recognitionSign" id="recognitionSign"></input>
          </div>           

           <div class="form-group">
            <label for="about">About </label>
            <textarea id="about" id="about" class="form-control" name="about"></textarea>
          </div>          


          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--modal for add end-->   

<!--edit form--> 

<div class="modal fade" id="editform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update work log</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('updateUser')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

   

          <input type="hidden" name="id" value="">
          <div class="form-group">
            <label for="image">Add Image</label>
            <input type="file" class="form-control" name="image" id="image"></input>
          </div>
          <div class="form-group">
            <label for="name">User Name</label>
            <input class="form-control" name="name" id="name" required></input>
          </div>          

          <div class="form-group">
            <label for="age">Age</label>
            <input class="form-control" name="age" id="age"></input>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" name="email" id="email" required></input>
          </div>             

          <div class="form-group">
            <label for="password">Password</label>
            <input class="form-control" name="password" id="password" required></input>
          </div>           
          <div class="form-group">
            <label for="Address">Address</label>
            <input class="form-control" name="address" id="Address"></input>
          </div>           
          <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input class="form-control" name="phoneNumber" id="phoneNumber"></input>
          </div>           

           <div class="form-group">
            <label for="region">Region Number</label>
            <input class="form-control" name="region" id="region"></input>
          </div>           

           <div class="form-group">
            <label for="zipCode">Zip Code</label>
            <input class="form-control" name="zipCode" id="zipCode"></input>
          </div>              

          <div class="form-group">
            <label for="recognitionSign">Recognition Sign</label>
            <input class="form-control" name="recognitionSign" id="recognitionSign"></input>
          </div>           

           <div class="form-group">
            <label for="about">About </label>
            <textarea id="about" id="about" class="form-control" name="about"></textarea>
          </div>          


          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--edit form end--> 

<!--send mail-->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Send Mail</h4>
      </div>
      <div class="modal-body">
          <form class="form" method="post" action="<?php echo e(route('sendBooking')); ?>">
             <?php echo e(csrf_field()); ?>

             <input id="id" name="id" type="hidden"></input>
              <div class="form-group">
                  <label>Select Class</label>
                  <select class="form-control" name="region">
                      <option value="dhaka">dhaka</option>
                      <option value="khulna">khulna</option>
                  </select>
              </div>

              <div class="form-group">
                  <button class="btn-success btn">Send Mail</button>
              </div>
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!--send mail end-->
	</div><!--main  col div end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script type="text/javascript">
		function edit(id, name, email,address,phoneNumber,age,region,zipCode,recognitionSign,password){
      $('[name="id"]').val(id);
      $('[name="name"]').val(name);
      $('[name="email"]').val(email);
      $('[name="address"]').val(address);
      $('[name="phoneNumber"]').val(phoneNumber);
      $('[name="age"]').val(age);
      $('[name="region"]').val(region);
      $('[name="zipCode"]').val(zipCode);
      $('[name="recognitionSign"]').val(recognitionSign);
      $('[name="password"]').val(password);
		}

//deleting 
 
	</script>
  <script type="text/javascript">
      function sendMail(id){
          $("#id").val(id);
      }
      function deleteUser(id){
       

        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
            $.ajax({

              url : "http://newgen-bd.com/dashboard/delete-user/"+id,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                  alert(data);
               $("#dlt").closest("tr").remove();
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error deleting data');
              }
          });

        }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>