<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-lg-3 col-md-3">
			<?php $url= url('storage/app/avatars/');?>
			<?php if(!empty($user->image)):?>
			<div class="form-group">
				<img src="<?php echo e($url.'/'.$user->image); ?>">
			</div>
			<?php else:?>
			<div class="form-group">
				<img src="<?php echo e($url.'/man.png'); ?>">
			</div>				
			<?php endif?>
			<div class="detail">
				<strong><p>Name: <?php echo e($user->name); ?></p></strong>
				<strong><p>Email: <?php echo e($user->email); ?></p></strong>
				<strong><p>About: <?php echo e($user->about); ?></p></strong>
			</div>
		</div>

		<div class="col-lg-9 col-md-9">
		<?php if(Session::has('success')): ?>
		<div class="alert alert-success  alert-dismissible  show" role="alert">
			<h4><?php echo Session::get('success'); ?></h4>
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			  </button>
		</div>
		<?php endif; ?>
		<?php if(Session::has('fail')): ?>
		<div class="alert alert-danger  alert-dismissible  show" role="alert">
			<h4><?php echo Session::get('fail'); ?></h4>
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			  </button>			
		</div>	
		<?php endif; ?>	
			
			<div class="panel panel-default">
				<div class="panel-heading">
					Update Account

				</div>
				<div class="panel-body">
					<form class="form-horizontal form col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3" method="post" action="<?php echo e(route('updateAccount')); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>Image</label>
							<input type="file" class="form-control" name="image"/>
							<input type="hidden" name="img" value="<?php echo e($user->image); ?>">
							<input type="hidden" name="img_path" value="<?php echo e($user->image_path); ?>">
							<input type="hidden" name="password" value="<?php echo e($user->password); ?>">
						</div>			

						<div class="form-group">
							<label>Name</label>
							<input class="form-control" name="name" value="<?php echo e($user->name); ?>"/>
						</div>			

						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>"/>
						</div>			

						<div class="form-group">
							<label>About</label>
							<input class="form-control" name="about" value="<?php echo e($user->about); ?>"/>
						</div>			
						<div class="form-group">
							<button type="submit" class="btn btn-default" name="submit">Update Account</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>