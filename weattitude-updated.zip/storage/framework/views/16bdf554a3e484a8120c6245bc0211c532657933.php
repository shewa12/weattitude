<?php $__env->startSection('content'); ?>
  <div class="right_col" role="main">
      <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  

        <div class="responsive">
            <button class="btn-default btn btn-sm" data-toggle="modal" data-target="#addform"><i class="fas fa-plus-circle"></i> Recommendation / Initiatives</button>
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>Sl No:</th>
                    <th>Regions</th>
                    <th>Issue</th>
                    <th>Recommendation</th>
                    <th>Initiatives</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $i=1;
                  ?>

                <?php $__empty_1 = true; $__currentLoopData = $recomm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->location_name); ?></td>
                    <td><?php echo e($value->content); ?></td>
                    <td><?php echo e($value->recommendation); ?></td>
                    <td><?php echo e($value->initiatives); ?></td>

                     
                        <?php 
                        /*
                        echo 
                        '
                        <i class="fas fa-edit" onClick ="edit('.$value->id.',\''.$value->name.'\')" data-toggle="modal" data-target="#editform"
                        aria-hidden="true" style="color:green; font-size:18px;cursor:pointer;"></i>

                        ';
                        */
                        ?>
                        
                        <td class="" id="dlt"><i id="delete" onClick="deleteUser(<?php echo e($value->id); ?>)" class=" fas fa-trash-alt" style="color:red; font-size:18px;cursor:pointer;"></i></td>                   
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                  <tr>
                    <td>No record found</td>
                  </tr>
                <?php endif; ?>
                </tbody>
            </table>    
        </div>      

<!-- Modal for add -->
<div class="modal fade" id="addform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Recommendation / Initiatives</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('saveRecomm')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>


          <div class="form-group">
            <label for="name">Select Issue</label>
            <select class="form-control" name="issue_id">
              <?php $__empty_1 = true; $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($value->id); ?>"><?php echo e($value->location_name); ?> -- <?php echo e($value->content); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <option>No record found</option>
              <?php endif; ?>  
            </select>
          </div>          

          <div class="form-group">
            <label>Recommendation</label>
            <textarea class="form-control" name="recommendation" placeholder="add recommendation"></textarea>
          </div>          

          <div class="form-group">
            <label>Initiatives</label>
            <textarea class="form-control" name="initiatives" placeholder="add initiatives"></textarea>
          </div>

          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--modal for add end-->   

<!--edit form--> 

<div class="modal fade" id="editform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Service</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('updateIssue')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

          <input type="hidden" name="id">
          <div class="form-group">
            <label for="name">Name</label>
            <input class="form-control" name="name" id="name" required></input>
          </div>          

          <div class="form-group">
            <button type="submit" class="btn-default btn" id="save">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--edit form end--> 
  </div><!--main  col div end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script type="text/javascript">
    function edit(id, name){
      $('[name="id"]').val(id);
      $('[name="name"]').val(name);

    }

//deleting 
 
  </script>
  <script type="text/javascript">

      function deleteUser(id){
        
       var url ="<?php echo url('delete-recommendation')?>";

        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
            $.ajax({

              url : url+'/'+id,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                  
               $("#dlt").closest("tr").remove();
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error deleting data');
              }
          });

        }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>