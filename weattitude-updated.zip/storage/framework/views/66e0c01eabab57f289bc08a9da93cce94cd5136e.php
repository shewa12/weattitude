<?php $__env->startSection('content'); ?>
<div class="cointainer otherpage-area">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<form class="form-horizontal" action="" method="">
				<h1 class="page-title">Issues & Suggested Solutions</h1>
			  <div class="input-group">
			    <span class="input-group-addon"><i class="fas fa-search"></i></span>
			    <input id="search" onKeyup="getLocations()" type="text" class="form-control" name="region" placeholder="Search your region...">
			  </div>
			  <div class="search-result" style="padding: 0px 15px;"></div>
			  <div class="form-group" style="margin-left: 1px;margin-top: 20px;">
			  		<button type="button" class="btn-default btn" id="searchBtn">Search <i  class="fas fa-spinner fa-spin" id="loading" style="padding-left:5px;color:blue"></i></button>
			  		<button type="button" data-target="#advanceSearch" data-toggle="modal" class="btn-primary btn">Advance Search </button>
			  </div>
			</form>
		</div>

	</div>

  <div class="row" id="result"></div>
	<div class="row" id="advanceSearchresultForAll"></div>
</div>

<!--advance search modal-->
<div id="advanceSearch" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Advance Search</h4>
      </div>
      <div class="modal-body">
          <form class="form" action="<?php echo e(route('advanceSearch')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                  <label>Search Solution</label>
                  <input class="form-control" onKeyup="solution(this.value)" name="recommendation" placeholder="Search solution"></input>

                  <div class="solution-result"></div>
              </div>              

              <div class="form-group">
                  <label>Search Issue</label>
                  <input class="form-control" onKeyup="searchIssue(this.value)" name="issue" placeholder="Search issue"></input>

                  <div class="issue-result"></div>
              </div>              

              <div class="form-group">
                  <label>Search Region</label>
                  <input class="form-control" onKeyup="advanceSearch(this.value)" name="region" placeholder="Search region"></input>    
                  <div class="advance-search-result"></div>      
              </div>              

              <div class="form-group">
                  <button type="submit" onClick="advanceSearchResult()" class="btn-primary btn">Search <span id="loading"><i class="fas fa-spinner fa-spin"></i></span></button>
              </div>
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!--advance search modal-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  function getLocations(){
        var location= $("#search").val();


            $.ajax({

              url : "<?php echo url('visitor-search-region')?>"+'/'+location,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                 console.log(data); 
               	$(".search-result").html(data);
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  //alert('Error deleting data');
              }
          });
  }

  $(document).ready(function(){
        $("#searchBtn").click(function(){
        var id=	$( "#region option:selected" ).val();
           
    $.ajax({
        url:"<?php echo url('issue-by-region')?>"+"/"+id,
        type:"GET",
        dataType:"HTML",
        beforeSend:function(){
            $("#loading").show();
        },
        success:function(data){
        	
            $("#loading").hide();
            
            $("#result").html(data);
            
        },
        error:function(){
          alert("error");
        }
    });            
            
        });
  });  

  function solution(solution){
            $.ajax({

              url : "<?php echo url('visitor-search-solution')?>"+'/'+solution,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                 console.log(data); 
                $(".solution-result").html(data);
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  //alert('Error deleting data');
              }
          });      
  }

  function searchIssue(issue){

            $.ajax({

              url : "<?php echo url('visitor-search-issue')?>"+'/'+issue,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                 console.log(data); 
                $(".issue-result").html(data);
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  //alert('Error deleting data');
              }
          });      
  }  

  function advanceSearch(location){
        //var location= $("#search").val();


            $.ajax({

              url : "<?php echo url('visitor-search-region')?>"+'/'+location,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                 console.log(data); 
                $(".advance-search-result").html(data);
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  //alert('Error deleting data');
              }
          });
  }  





</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>