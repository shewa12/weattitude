<html>
<head>
	<title></title>
    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">	
</head>
<body>
	<div class="panel panel-default">
		<div class="panel-heading">
			<strong>Employee Name: <?php echo e(Auth::user()->name); ?></strong>
		</div>

		<div class="panel-body">
			<div class="responsive">
				<table class="table-bordered table">
					<thead>
						<tr>
							<th>date</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php echo e(date('Y-m-d')); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</body>
</html>