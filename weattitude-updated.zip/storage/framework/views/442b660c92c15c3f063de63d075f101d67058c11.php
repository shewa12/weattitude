<?php $__env->startSection('content'); ?>
	<div class="right_col" role="main">
		  <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  
<!--issue list-->
<div class="row main-content">
  <div class="panel-default panel">
    <?php// print_r($selected_region);?>
    <div class="panel-heading">
      <h3>
        <?php  $n=count($selected_region);?>
        What are issues in [

          <?php $__empty_1 = true; $__currentLoopData = $selected_region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$i): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <?php echo e($i->location_name); ?>

            <?php if($k<$n-1): ?>
            <?php echo e(","); ?>

            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
          <?php endif; ?>
        ]

      </h3>
    </div>
    <div class="panel-body">
      <div class="col-sm-10">
          <h4><?= count($issues);?> Issue listed</h4>
      </div>
      <div class="col-sm-2">
          <button type="button" class="btn-primary btn" data-toggle="modal" data-target="#addIssue"><i class="fas fa-plus-circle"></i> Add Issue</button>
      </div>
    </div>
  </div>
<?php $__empty_1 = true; $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
  <div class="panel panel-default">
    <div class="panel-body issue-content">
      
      <div class="col-xs-11 pull-left"><?php echo e($value->content); ?></div>
      <div class="col-xs-1 pull-right">
          <i class="fas fa-th-list toggle-icon dropdown-toggle"data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"style="cursor:pointer"></i>

        <ul class="dropdown-menu">
          <li><a href="#"class="rating"  data-target="#addRating" id="<?php echo e($value->id); ?>" data-toggle="modal">Give Rating</a></li>
          
          <li><a href="#" class="mark_delete" id="<?php echo e($value->id); ?>">Mark for Delete</a></li>
          
          <li><a href="#">Suggest to Rename</a></li>
          
          <li><a href="#">Offer Recommendation</a></li>

          <li><a href="#">Offer for OR Against Remark</a></li>
        </ul>
      </div>

    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
  <div class="panel-default panel">
    <div class="panel-body">
      <strong>No record found</strong>
    </div>
  </div>
<?php endif; ?>

</div>
<!--issue list end-->

<!-- Modal for add -->
<div class="modal fade" id="addIssue" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Issue</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('saveIssue')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

          <?php $arr=[];?>
          <?php $__empty_1 = true; $__currentLoopData = $selected_region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <?php $arr[]=$sr->id?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
          <?php endif; ?>   
          <input type="hidden" name="region_id" value="<?php echo implode(',',$arr)?>"> 
          <div class="form-group">
            
            <textarea onKeyup="checkDuplicate()" class="form-control" name="content" placeholder="Enter text here... max 250 words"></textarea>
           
            <span class="word-used" style="color:green;"></span>
          </div>
          <div class="help-block"></div>
          <div class="form-group">
            <button type="submit" class="btn-default btn" id="submit">Submit</button>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--modal for add end-->   

<!--edit form--> 

<div class="modal fade" id="addRating" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Give a rating</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="text-align:center;font-size:25px;">
        <form method="post" action="" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

          <input type="hidden" name="type_id">
          <input type="hidden" name="type" value="issue">

          <div class="checkbox">
            <i type="checkbox" id="checkbox" name="rating" value="1" class="far fa-thumbs-up bubbly-button"></i>
            <i class="far fa-thumbs-up bubbly-button" id="1"></i>
            <i class="far fa-thumbs-up bubbly-button" id="2"></i>
            <i class="far fa-thumbs-up bubbly-button" id="3"></i>
            <i class="far fa-thumbs-up bubbly-button" id="4"></i>
            <i class="far fa-thumbs-up bubbly-button" id="5"></i>

          </div>          


        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--edit form end--> 
	</div><!--main  col div end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script type="text/javascript">

		function edit(id, name){
      $('[name="id"]').val(id);
      $('[name="name"]').val(name);

		}

//deleting 
 
	</script>
  <script type="text/javascript">

      function deleteUser(id){
        
       var url ="<?php echo url('delete-issue')?>";

        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
            $.ajax({

              url : url+'/'+id,            
              type: "GET",
              dataType: "HTML",
              success: function(data)
              {
                  
               $("#dlt").closest("tr").remove();
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error deleting data');
              }
          });

        }
      }

      function checkDuplicate(){
          var csrf_token= $('meta[name="csrf-token"]').attr('content');
          var region_id= $('[name="region_id"]').val();
          var content= $('[name="content"]').val();
          var dataString = {
            _token:csrf_token,
            region_id:region_id,
            content:content
          };
        if(content !==''){
            $.ajax({

              url: "<?php echo url('check-duplicate-issue')?>",            
              type: "POST",
              data: dataString,
              dataType: "HTML",
              success: function(data)
              {
                 console.log(data);
                  if(data=="duplicate"){
                    $(".help-block").html("Possible duplicate issue");
                    countMatch(content);
                    $("#submit").attr('disabled',true);
                  }
                  else{
                    $(".help-block").empty();
                    countMatch(content);
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  $(".word-used").empty();
                  console.log('Error matching duplicate data');
              }
          }); 
            
        } //endif        
      }
      function countMatch(content){
        $(".word-used").empty();
        var matches= content.match(/\S+/g) ;
        var length= matches?matches.length:0;
        $(".word-used").html(250-length+" word remaining");
        if(length>250){
            $("#submit").attr('disabled',true);
            
        }
        else{
            $("#submit").attr('disabled',false);
        }
      }
      //count match end
      //rating
      var rating;

      $(".fa-thumbs-up").on('click',function(){
          rating= $(this).attr('id');
          $(".fa-thumbs-up").removeClass('active-thumb');
          $(".fa-thumbs-up").removeClass('shake');
          $(this).addClass('active-thumb shake');

          var typeId= $('[name="type_id"]').val();
          var csrf_token= $('meta[name="csrf-token"]').attr('content');
          var dataString= {
            _token:csrf_token,
            
            type_id:typeId,
            rating:rating
          };

            $.ajax({

              url:"<?php echo url('/issue-rating')?>",            
              type: "POST",
              data:dataString,
              dataType: "HTML",
              success: function(data)
              {
                if(data=="exists"){
                    alert("You have already submited rating!");
                    return ;
                }
                else{
                  location.reload();   
                  alert("Rating posted!");
                  console.log(data);
                                
                }

                  
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  console.log('Error posting rating');
              }
          });



      });//function close
      //rating end
      //set issue id
      $(".rating").click(function(){
        $(".fa-thumbs-up").removeClass('active-thumb shake');
        var issue_id= $(this).attr('id');
        $('[name="type_id"]').val(issue_id);
      });
      //set issue id end

      $(".mark_delete").on('click',function(){
            var issue_id= $(this).attr('id');
            
            $.ajax({

              url:"<?php echo url('/issue-mark-delete')?>"+'/'+issue_id,            
              type: "GET",
             
              dataType: "HTML",
              success: function(data)
              {
                 alert(data);
                  
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  console.log('Error posting rating');
              }
          });
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>