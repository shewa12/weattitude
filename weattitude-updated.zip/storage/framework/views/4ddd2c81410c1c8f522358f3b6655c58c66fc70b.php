<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Simple Markers</title>
    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" id="theme" type="text/css" href="<?php echo e(url('public/css/homepage.css')); ?>"/>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 450px;
      }
      /* Optional: Makes the sample page fill the window. */

    </style>
  </head>
<body>
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        WEattitude.org
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    YOURattitude <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                                    <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>

                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('home')); ?>">YOURattitude</a></li>
                        <?php endif; ?>
                            
                            <li><a href="<?php echo e(route('aboutUs')); ?>">About Us</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    Motivation Resources
                                     <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        
                                        <a href="<?php echo e(route('hangoutSheet')); ?>"><i class="fas fa-folder-open"></i> Handout Sheet for Your Community</a>
                                    </li>                                     
                                    <li>  
                                        <a href="<?php echo e(route('writingVideos')); ?>"><i class="fas fa-video"></i> Daily Collections of Uplifiting Writings & Videos</a>
                                    </li>                                     
                                    <li>

                                        <a href="<?php echo e(route('whyParticipate')); ?>"><i class="fas fa-undo-alt"></i> What do Participants Get in Return </a>
                                    </li> 
                                </ul>  
                            </li>              
                            <li class='dropdown'>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Ongoing Initiatives <span class="caret"></span></a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('issueSuggestedSolution')); ?>"><i class="fas fa-check-circle"></i>
                                            Issues & Suggested Solutions
                                        </a>
                                    </li>

                                    <li>
                                        <?php if(Auth::guest()): ?>
                                        <a href="<?php echo e(url('login')); ?>"><i class="fas fa-undo-alt"></i> Here is What You Can do</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('myProfile')); ?>"><i class="fas fa-undo-alt"></i> Here is What You Can do</a>
                                        <?php endif; ?>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(route('caseStudy')); ?>"><i class="fas fa-search"></i> Case Studies / Success Stories</a>
                                    </li>
                                </ul>
                            </li>
                                                
                        <?php if(Auth::guest()): ?>
                       
                        <?php else: ?>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('setting')); ?>">Setting</a>
                                    </li> <!--                         
                                    <li>
                                    <a href="<?php echo e(route('changePassword')); ?>">Change Password</a>
                                    </li>                         -->           
                                    <li>
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
<div class="clearfix"></div>
<div class="container otherpage">
    <div class="hidden">
        <input id="lat" value="<?php echo e($recomm->lat); ?>">
        <input id="lng" value="<?php echo e($recomm->lng); ?>">
        <input id="title" value="<?php echo e($recomm->location_name); ?>">
    </div>
  <div class="row">
        <h1 align="center" class="page-title" style="margin-bottom:50px">Issue Detail</h1>
      <div class="col-md-4">
            <div class="panel-default panel">
                <div class="panel-body">
                    <h3>Region</h3>
                    <p><?php echo e($recomm->location_name); ?></p>
                </div>                
            </div>           
             <div class="panel-default panel">
                <div class="panel-body">
                    <h3>Issue</h3>
                    <p><?php echo e($recomm->content); ?></p>
                </div>               
            </div>             
            
            <div class="panel-default panel">
                <div class="panel-body">
                    <h3>Severity</h3>
                    <p><?php echo e($recomm->severity); ?></p>
                </div>               
            </div>             
            <div class="panel-default panel">
                <div class="panel-body">
                    <h3>Initiatives</h3>
                    <p><?php echo e($recomm->initiatives); ?></p>
                </div>               
            </div>            
            <div class="panel-default panel">
                <div class="panel-body">
                    <h3>Recommendation</h3>
                    <p><?php echo e($recomm->recommendation); ?></p>
                </div>               
            </div>
      </div>

      <div class="col-md-8">
          <div id="map"></div>
      </div>
  </div>
</div>
    <script src="<?php echo e(url('public/js/2.1.4-jquery.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/app.js')); ?>"></script> 
    <script>

    var lat = parseFloat(document.getElementById('lat').value);
    var lng = parseFloat(document.getElementById('lng').value);
    var title = document.getElementById('title').value;
                //var lng= $('[name="lng"]').val();
                
                function initMap() {
                var myLatLng = {lat: lat, lng: lng};

                var map = new google.maps.Map(document.getElementById('map'), {
                  zoom: 8,
                  center: new google.maps.LatLng(lat, lng)
                });

                var marker = new google.maps.Marker({
                  position: myLatLng,
                  map: map,
                  title: title
                });
              }

    </script>
    
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDgB7vF_nyTAIBpEyHUjtE0bzNXoTNrqcc&callback=initMap">
    </script>

  </body>
</html>