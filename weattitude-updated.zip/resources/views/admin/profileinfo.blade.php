            <div class="profile clearfix">
           
              <div class="profile_pic">
              	
              </div>
              <div class="profile_info">
                <span>Welcome, <strong>{{Auth::user()->name}}</strong></span>

              </div>

            </div>