<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Funds extends Model
{
    //table name
    public $timestamps = false;
    protected $guarded= [];
}
