<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class InitiativeSuggestion extends Model
{
    public $table= "initiatives_suggestion";
    protected $guarded=[];
}
