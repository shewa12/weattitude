<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class IssueRecommJunction extends Model
{
    public $table= "issue_recomm_junction";
    protected $guarded=[];
    public $timestamps = false;

}
