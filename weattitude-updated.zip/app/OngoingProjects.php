<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class OngoingProjects extends Model
{
    //table name
    public $table= "ongoing_project";
    protected $guarded= [];
}
