<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Regions extends Model
{
    //table name
    //public $table= "locations";
    protected $guarded= [];
}
