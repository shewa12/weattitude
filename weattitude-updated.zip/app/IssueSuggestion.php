<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class IssueSuggestion extends Model
{
    public $table= "issue_suggestion";
    protected $guarded=[];
}
