<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class RegionIssueJunction extends Model
{
    public $table="region_issue_junction";
    protected $guarded=[];
    public $timestamps = false;
}
