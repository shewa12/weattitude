<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Features extends Model
{
    //table name
    public $table= "features";
    protected $guarded= [];
}
