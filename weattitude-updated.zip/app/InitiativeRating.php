<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class InitiativeRating extends Model
{
    public $table= "initiatives_rating";
    protected $guarded=[];
}
