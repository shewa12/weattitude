<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class IssueRating extends Model
{
    public $table= "issue_rating";
    protected $guarded=[];
}
