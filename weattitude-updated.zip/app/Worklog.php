<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Worklog extends Model
{
	public $table = "Worklog";
    protected $guarded=[];
}
