<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Recomm extends Model
{
    //table name
    public $table= "recomm";
    protected $guarded= [];
}
