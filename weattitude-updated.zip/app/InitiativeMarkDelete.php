<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class InitiativeMarkDelete extends Model
{
    public $table= "initiatives_mark_delete";
    protected $guarded=[];
}
