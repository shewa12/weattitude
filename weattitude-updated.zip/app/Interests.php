<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Interests extends Model
{
    //table name
    //public $table= "locations";
    protected $guarded= [];
}
