<?php

namespace admin\Http\Controllers;

use Illuminate\Http\Request;

class Test extends Controller
{
    //
}
