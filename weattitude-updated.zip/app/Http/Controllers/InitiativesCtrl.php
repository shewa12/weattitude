<?php

namespace admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;//auth for get logged in info
use admin\Issues;
use admin\Recomm;
use admin\Regions;
use admin\Locations;
use admin\Initiatives;
use admin\RecommInitJunction;

class InitiativesCtrl extends Controller
{
    function __construct(){
        $this->middleware('auth');
    }    

    function getInitiative(Request $request){
        $id= Auth::id();
        $title= "Initiatives";
        $recomm_id= $request->recomm_id;
        $init= Initiatives::select('initiatives.content')
                    ->join('recomm_init_junction as rij','rij.init_id','=','initiatives.id')
                    ->join('recomm as r','r.id','=','rij.recomm_id')
                    
                    ->whereIn('rij.recomm_id',$recomm_id)
                    ->orderBy('initiatives.id','desc')
                    ->get();


        return view('users/init')->with(['title'=>$title,'init'=>$init,'selected_recomm'=>$recomm_id]);
    }


    function checkDuplicateInit(){
        $recomm_id= explode(',',$_POST['recomm_id']);
        $initiatives= $_POST['initiatives'];

        $q= Initiatives::where('initiatives.content','like','%'.$initiatives.'%')
                ->join('recomm_init_junction as rij','rij.init_id','=','initiatives.id')
                ->join('recomm as r','r.id','=','rij.recomm_id')
                ->whereIn('rij.recomm_id',$recomm_id)
                ->get();                
        if(count($q)>0){
            echo "duplicate";
        }
        else{
            echo "ok";
        }

    }  
    function saveInit(Request $request){
        $user_id= Auth::id();
        $recomm_id= explode(',',$request->recomm_id);//str to arr

        $initiatives=[
            'user_id'=>$user_id,
            'content'=>$request->content
        ];
        //saving init 
        $saveInit= new Initiatives($initiatives);
        if($saveInit->save()){

            //get the latest id 
            $init_id= Initiatives::latest('id')->first();
     
            //putting record to recommInitJunction
            for($i=0; $i<count($recomm_id); $i++){
                $post=new RecommInitJunction([
                    'recomm_id'=>$recomm_id[$i],
                    'init_id'=>$init_id->id
                ]);
                $post->save();

            }         

        }
        else{
            return redirect()->route('home')->with('fail','Recommendation Add failed!');
        }

        return redirect()->route('home')->with('success','Recommendation Added!');
            //return redirect()->back()->with('success','Issue Added!');
    }

    function updateIssue(Request $request){
        $services = Issues::where('id', $request->id)
                        ->update(['name'=>$request->name]);
        if($services){
            return redirect()->route('getServices')->with('success','Service Updated!');

        } 
        else{
            return redirect()->route('getServices')->with('fail','Service Could Not Update!');

        }                   
    }

    function deleteRecomm($id){
        $user= Recomm::where('id',$id)
                     ->delete();
     
    }
}
