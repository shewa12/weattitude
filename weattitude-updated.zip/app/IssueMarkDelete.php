<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class IssueMarkDelete extends Model
{
    public $table= "issue_mark_delete";
    protected $guarded=[];
}
