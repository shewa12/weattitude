<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class RecommMarkDelete extends Model
{
    public $table= "recomm_mark_delete";
    protected $guarded=[];
}
