<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class RecommSuggestion extends Model
{
    public $table= "recomm_suggestion";
    protected $guarded=[];
}
