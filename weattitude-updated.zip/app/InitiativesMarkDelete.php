<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class InitiativesMarkDelete extends Model
{
    public $table= "initiatives_mark_delete";
    protected $guarded=[];
}
