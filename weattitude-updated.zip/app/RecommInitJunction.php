<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class RecommInitJunction extends Model
{
    public $table="recomm_init_junction";
    protected $guarded=[];
    public $timestamps = false;
}
