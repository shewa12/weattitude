<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class InterestDatas extends Model
{
    
    public  $table= "interesttext";
    protected $guarded= [];
}
