<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class RecommRating extends Model
{
    public $table= "recomm_rating";
    protected $guarded=[];
}
