<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Videos extends Model
{
    //table name
    //public $table= "services";
    protected $guarded= [];
}
