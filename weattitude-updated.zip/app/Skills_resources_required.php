<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Skills_resources_required extends Model
{
    //table name
    public $table= "skills_resources_required";
    protected $guarded= [];
}
