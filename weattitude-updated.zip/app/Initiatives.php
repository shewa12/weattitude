<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Initiatives extends Model
{
    //table name
    public $table= "initiatives";
    protected $guarded= [];
}
