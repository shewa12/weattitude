<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    public $table= "rating";
    protected $guarded=[];
}
